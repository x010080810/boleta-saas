--
-- PostgreSQL database dump
--

\restrict OR1kswqTcJ30Jpqu52d1Fban5eyufNVyAafh3EFuT1TrGIfvuK3xsRp1aoOhO1U

-- Dumped from database version 15.18
-- Dumped by pg_dump version 17.10 (Debian 17.10-0+deb13u1)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: companies; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.companies (
    id character varying(36) NOT NULL,
    name character varying(200) NOT NULL,
    ruc character varying(11) NOT NULL,
    logo_url text,
    plan_envios_mes integer NOT NULL,
    licencia_inicio date,
    licencia_fin date,
    licencia_grace_hasta date,
    licencia_estado character varying(20) NOT NULL,
    licencia_renovacion_automatica boolean NOT NULL,
    notificado_15_dias boolean NOT NULL,
    smtp_host character varying(255),
    smtp_port integer NOT NULL,
    smtp_user character varying(255),
    smtp_password text,
    smtp_from_email character varying(255),
    smtp_from_name character varying(200),
    email_subject_template text,
    email_body_template text,
    pdf_password_field character varying(50) NOT NULL,
    is_active boolean NOT NULL,
    created_at timestamp with time zone NOT NULL
);


--
-- Name: company_users; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.company_users (
    id character varying(36) NOT NULL,
    email character varying(255) NOT NULL,
    hashed_password character varying(255) NOT NULL,
    full_name character varying(200) NOT NULL,
    is_active boolean NOT NULL,
    created_at timestamp with time zone NOT NULL
);


--
-- Name: email_logs; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.email_logs (
    id character varying(36) NOT NULL,
    company_id character varying(36) NOT NULL,
    pay_slip_id character varying(36) NOT NULL,
    payroll_upload_id character varying(36),
    batch_key character varying(50) NOT NULL,
    destinatario_email character varying(255) NOT NULL,
    estado character varying(20) NOT NULL,
    error_message text,
    enviado_en timestamp with time zone,
    created_at timestamp with time zone NOT NULL
);


--
-- Name: employee_company_assignments; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.employee_company_assignments (
    employee_id character varying(36) NOT NULL,
    company_id character varying(36) NOT NULL,
    cargo character varying(200),
    fecha_ingreso date,
    is_active boolean NOT NULL
);


--
-- Name: employees; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.employees (
    id character varying(36) NOT NULL,
    tipo_documento character varying(2) NOT NULL,
    numero_documento character varying(20) NOT NULL,
    nombre_completo character varying(200) NOT NULL,
    email character varying(255),
    created_at timestamp with time zone NOT NULL
);


--
-- Name: license_history; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.license_history (
    id character varying(36) NOT NULL,
    company_id character varying(36) NOT NULL,
    tipo character varying(20) NOT NULL,
    inicio_anterior date,
    fin_anterior date,
    plan_anterior integer,
    inicio_nuevo date,
    fin_nuevo date,
    plan_nuevo integer,
    notas text,
    creado_por character varying(36),
    created_at timestamp with time zone NOT NULL
);


--
-- Name: monthly_send_quotas; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.monthly_send_quotas (
    id character varying(36) NOT NULL,
    company_id character varying(36) NOT NULL,
    anio integer NOT NULL,
    mes integer NOT NULL,
    limite integer NOT NULL,
    utilizados integer NOT NULL,
    created_at timestamp with time zone NOT NULL
);


--
-- Name: pay_slips; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.pay_slips (
    id character varying(36) NOT NULL,
    company_id character varying(36) NOT NULL,
    payroll_upload_id character varying(36) NOT NULL,
    employee_id character varying(36),
    tipo_documento character varying(2) NOT NULL,
    numero_documento character varying(20) NOT NULL,
    nombre_completo character varying(200) NOT NULL,
    email_destino character varying(255),
    cargo character varying(200),
    pdf_path text,
    pdf_password text,
    datos_json json,
    ingresos_json json,
    descuentos_json json,
    aportaciones_json json,
    total_ingresos double precision NOT NULL,
    total_descuentos double precision NOT NULL,
    neto_pagar double precision NOT NULL,
    neto_pagar_usd double precision,
    total_aportaciones double precision NOT NULL,
    es_observacion boolean NOT NULL,
    motivo_observacion text,
    estado_envio character varying(20) NOT NULL,
    batch_key character varying(50) NOT NULL,
    error_message text,
    enviado_en timestamp with time zone,
    created_at timestamp with time zone NOT NULL
);


--
-- Name: payroll_uploads; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.payroll_uploads (
    id character varying(36) NOT NULL,
    company_id character varying(36) NOT NULL,
    ticket_number character varying(50) NOT NULL,
    tipo_planilla character varying(30) NOT NULL,
    periodo_mes integer NOT NULL,
    periodo_ano integer NOT NULL,
    filename character varying(255) NOT NULL,
    file_path text,
    total_registros integer NOT NULL,
    total_procesados integer NOT NULL,
    total_observaciones integer NOT NULL,
    total_enviados integer NOT NULL,
    total_fallidos integer NOT NULL,
    total_sin_saldo integer NOT NULL,
    estado character varying(20) NOT NULL,
    resumen_json json,
    observaciones_json json,
    detalle_envios_json json,
    ticket_enviado_en timestamp with time zone,
    created_at timestamp with time zone NOT NULL,
    procesado_en timestamp with time zone
);


--
-- Name: super_admins; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.super_admins (
    id character varying(36) NOT NULL,
    email character varying(255) NOT NULL,
    hashed_password character varying(255) NOT NULL,
    full_name character varying(200) NOT NULL,
    is_active boolean NOT NULL,
    created_at timestamp with time zone NOT NULL
);


--
-- Name: unregistered_workers; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.unregistered_workers (
    id character varying(36) NOT NULL,
    payroll_upload_id character varying(36) NOT NULL,
    tipo_documento character varying(2) NOT NULL,
    numero_documento character varying(20) NOT NULL,
    nombre_completo character varying(200) NOT NULL,
    email_destino character varying(255),
    datos_json json,
    pdf_generado boolean NOT NULL,
    boleta_enviada boolean NOT NULL,
    created_at timestamp with time zone NOT NULL
);


--
-- Name: user_company_assignments; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.user_company_assignments (
    user_id character varying(36) NOT NULL,
    company_id character varying(36) NOT NULL,
    role character varying(20) NOT NULL
);


--
-- Data for Name: companies; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.companies (id, name, ruc, logo_url, plan_envios_mes, licencia_inicio, licencia_fin, licencia_grace_hasta, licencia_estado, licencia_renovacion_automatica, notificado_15_dias, smtp_host, smtp_port, smtp_user, smtp_password, smtp_from_email, smtp_from_name, email_subject_template, email_body_template, pdf_password_field, is_active, created_at) FROM stdin;
emp-002	OTRA EMPRESA S.A.C.	20456789012	\N	50	2026-01-01	2026-09-30	2026-11-30	activa	f	f	\N	587	\N	\N	admin@otraempresa.com	Otra Empresa	\N	\N	numero_documento	t	2026-07-11 01:35:34.717532+00
emp-001	LA VALETA CONSULTORES S.A.C.	20567890123	\N	100	2026-01-01	2026-12-31	2027-03-01	activa	f	f	sandbox.smtp.mailtrap.io	587	5e9230575914d0	39f567281e3688	boletas@lavaleta.com	LA VALETA CONSULTORES	\N	\N	numero_documento	t	2026-07-11 01:35:34.711931+00
\.


--
-- Data for Name: company_users; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.company_users (id, email, hashed_password, full_name, is_active, created_at) FROM stdin;
user-001	admin@lavaleta.com	$2b$12$EGz35dhSXjMdpnzMK9svtegv3SPfXGC87EDFGSVeuTiuh10w.h6g6	Admin LA VALETA	t	2026-07-11 01:35:34.721396+00
user-002	admin@otraempresa.com	$2b$12$upmJQQd1SDW8FBM.VSKBD.HvX1An5OoK5Z9FhwzJZJBp3CW9PLHR2	Admin Otra Empresa	t	2026-07-11 01:35:34.721402+00
user-003	admin@multi.com	$2b$12$KgABv5WPPYvA.ks9EbQxS.VP8q/fFOOJ7k7ihIVGmQeSsAxJM6Oda	Admin Multi Empresa	t	2026-07-11 01:35:34.721404+00
\.


--
-- Data for Name: email_logs; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.email_logs (id, company_id, pay_slip_id, payroll_upload_id, batch_key, destinatario_email, estado, error_message, enviado_en, created_at) FROM stdin;
c4e65f23-cd43-4356-b95f-645502b24843	emp-001	a96c8c07-1a12-43c9-ae42-4c611723488f	0e1b2998-7cf9-4495-851a-9258f7591803	original	gabriella@email.com	sent	\N	\N	2026-07-11 01:35:43.723858+00
57fe3fb7-96b5-4b52-90dd-7b18b2ab78b5	emp-001	24124011-a830-4be1-a05a-d0181f8e3acc	0e1b2998-7cf9-4495-851a-9258f7591803	original	juan@email.com	failed	(550, b'5.7.0 Too many emails per second. Please upgrade your plan https://mailtrap.io/billing/plans/testing')	\N	2026-07-11 01:35:45.640011+00
854fe693-01ae-4971-9a8c-1f97c80f9355	emp-001	47d7fc30-9a95-41a7-99a2-594c7e906468	0e1b2998-7cf9-4495-851a-9258f7591803	original	maria@email.com	failed	(550, b'5.7.0 Too many emails per second. Please upgrade your plan https://mailtrap.io/billing/plans/testing')	\N	2026-07-11 01:35:47.423655+00
5002998c-509c-4fdc-a210-12392b2980d3	emp-001	64cf87a5-c4c2-4954-8a82-5edd80913008	0e1b2998-7cf9-4495-851a-9258f7591803	original	pedro@email.com	failed	(550, b'5.7.0 Too many emails per second. Please upgrade your plan https://mailtrap.io/billing/plans/testing')	\N	2026-07-11 01:35:49.285585+00
5044ec64-e7e3-49c3-bb7d-7427e4760983	emp-001	b524e015-7916-405d-b5ea-4b88d6d4db42	0e1b2998-7cf9-4495-851a-9258f7591803	original	ana@email.com	failed	(550, b'5.7.0 Too many emails per second. Please upgrade your plan https://mailtrap.io/billing/plans/testing')	\N	2026-07-11 01:35:51.135621+00
4bd2830a-be2e-4219-8a19-e8cb22e3d6c6	emp-001	a96c8c07-1a12-43c9-ae42-4c611723488f	0e1b2998-7cf9-4495-851a-9258f7591803	resend_7_11	gabriella@email.com	enviado	\N	\N	2026-07-11 01:36:54.00911+00
d7da96f8-b20a-417a-9e7f-6e6a52ba0266	emp-001	24124011-a830-4be1-a05a-d0181f8e3acc	0e1b2998-7cf9-4495-851a-9258f7591803	resend_7_11	juan@email.com	fallido	(550, b'5.7.0 Too many emails per second. Please upgrade your plan https://mailtrap.io/billing/plans/testing')	\N	2026-07-11 01:36:54.009125+00
9cb1c887-7d7b-439f-88b7-82f2c69dd59c	emp-001	47d7fc30-9a95-41a7-99a2-594c7e906468	0e1b2998-7cf9-4495-851a-9258f7591803	resend_7_11	maria@email.com	fallido	(550, b'5.7.0 Too many emails per second. Please upgrade your plan https://mailtrap.io/billing/plans/testing')	\N	2026-07-11 01:36:54.009135+00
b5fe101c-e3cc-46a4-9a3f-6845ad800ffb	emp-001	64cf87a5-c4c2-4954-8a82-5edd80913008	0e1b2998-7cf9-4495-851a-9258f7591803	resend_7_11	pedro@email.com	fallido	(550, b'5.7.0 Too many emails per second. Please upgrade your plan https://mailtrap.io/billing/plans/testing')	\N	2026-07-11 01:36:54.009142+00
24b4d7dd-5490-4cbe-ad36-0e5d39715d12	emp-001	b524e015-7916-405d-b5ea-4b88d6d4db42	0e1b2998-7cf9-4495-851a-9258f7591803	resend_7_11	ana@email.com	fallido	(550, b'5.7.0 Too many emails per second. Please upgrade your plan https://mailtrap.io/billing/plans/testing')	\N	2026-07-11 01:36:54.009149+00
0ca4753a-4679-4422-91f8-8ac82fa3d8e3	emp-001	24124011-a830-4be1-a05a-d0181f8e3acc	0e1b2998-7cf9-4495-851a-9258f7591803	resend_7_11	juan@email.com	enviado	\N	\N	2026-07-11 01:42:46.6264+00
8615f156-c0e3-4287-a6ce-c067aac42331	emp-001	0b87b16f-19f3-473c-85df-73d670649a12	cd4aa46d-3a1f-4025-8025-3bb10397416b	original	gabriella@email.com	sent	\N	\N	2026-07-11 01:45:16.031297+00
81ac939b-ccf1-4223-ae00-1f05903a8eaa	emp-001	ed955801-49c3-419a-969d-8b3a3589da2d	cd4aa46d-3a1f-4025-8025-3bb10397416b	original	juan@email.com	no_enviado_sin_saldo	Sin saldo disponible en el plan mensual	\N	2026-07-11 01:45:16.44447+00
210b4029-1190-4fa4-aed6-c3aa1473bcdd	emp-001	492e68ce-371a-4b1b-bd17-33e046002c23	cd4aa46d-3a1f-4025-8025-3bb10397416b	original	maria@email.com	no_enviado_sin_saldo	Sin saldo disponible en el plan mensual	\N	2026-07-11 01:45:16.724185+00
e43c2121-5c85-487f-9e2a-0a859eba7eb2	emp-001	ed33bd1d-9c7d-4fc1-9dc2-d8d6eb9a7fd9	cd4aa46d-3a1f-4025-8025-3bb10397416b	original	pedro@email.com	no_enviado_sin_saldo	Sin saldo disponible en el plan mensual	\N	2026-07-11 01:45:16.998497+00
b40e98f2-a508-4692-9b53-1e513db30d6a	emp-001	c05b2174-893f-44db-8d45-858d18fe0630	cd4aa46d-3a1f-4025-8025-3bb10397416b	original	ana@email.com	no_enviado_sin_saldo	Sin saldo disponible en el plan mensual	\N	2026-07-11 01:45:17.293685+00
\.


--
-- Data for Name: employee_company_assignments; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.employee_company_assignments (employee_id, company_id, cargo, fecha_ingreso, is_active) FROM stdin;
emp-01	emp-001	HEAD OF OPERATIONS	2020-04-01	t
emp-02	emp-001	ANALISTA CONTABLE	2021-03-15	t
emp-03	emp-001	GERENTE ADMINISTRATIVO	2019-06-01	t
emp-04	emp-001	ASISTENTE RRHH	2022-01-10	t
emp-05	emp-001	CONTADOR GENERAL	2020-08-20	t
\.


--
-- Data for Name: employees; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.employees (id, tipo_documento, numero_documento, nombre_completo, email, created_at) FROM stdin;
emp-01	01	002976650	LARSSON IDA GABRIELLA MAGDALENA	gabriella@email.com	2026-07-11 01:35:34.725176+00
emp-02	01	73666629	QUISPE MAMANI JUAN CARLOS	juan@email.com	2026-07-11 01:35:34.725182+00
emp-03	01	12345678	PEREZ GOMEZ MARIA ELENA	maria@email.com	2026-07-11 01:35:34.725184+00
emp-04	01	87654321	TORRES LOPEZ PEDRO ANTONIO	pedro@email.com	2026-07-11 01:35:34.725185+00
emp-05	01	45678912	CASTRO DIAZ ANA MARIA	ana@email.com	2026-07-11 01:35:34.725186+00
\.


--
-- Data for Name: license_history; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.license_history (id, company_id, tipo, inicio_anterior, fin_anterior, plan_anterior, inicio_nuevo, fin_nuevo, plan_nuevo, notas, creado_por, created_at) FROM stdin;
be335fb5-ae51-4050-8fae-398970e3a941	emp-001	vencimiento	\N	\N	\N	\N	\N	\N	Licencia vencida automáticamente el 2026-07-11	\N	2026-07-11 01:43:54.533988+00
43c637af-149e-4be6-9819-9a7b2e9729d8	emp-001	renovacion	2026-01-01	2026-06-30	100	2026-01-01	2026-12-31	1	\N	admin-001	2026-07-11 01:44:15.228477+00
4302e6ae-fff2-47c1-93e7-38085733da3c	emp-001	renovacion	2026-01-01	2026-12-31	1	2026-01-01	2026-12-31	100	\N	admin-001	2026-07-11 01:45:39.471009+00
\.


--
-- Data for Name: monthly_send_quotas; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.monthly_send_quotas (id, company_id, anio, mes, limite, utilizados, created_at) FROM stdin;
452706ee-ad3f-4479-b1fd-c4b50c01b4f7	emp-001	2026	7	1	1	2026-07-11 01:35:34.755411+00
\.


--
-- Data for Name: pay_slips; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.pay_slips (id, company_id, payroll_upload_id, employee_id, tipo_documento, numero_documento, nombre_completo, email_destino, cargo, pdf_path, pdf_password, datos_json, ingresos_json, descuentos_json, aportaciones_json, total_ingresos, total_descuentos, neto_pagar, neto_pagar_usd, total_aportaciones, es_observacion, motivo_observacion, estado_envio, batch_key, error_message, enviado_en, created_at) FROM stdin;
ps-01	emp-001	upl-001	emp-01	01	002976650	LARSSON IDA GABRIELLA MAGDALENA	gabriella@email.com	CARGO EJEMPLO	output/boleta_002976650_test.pdf	002976650	{}	{"haber_basico": 23775.29}	{}	{}	23775.29	5419.21	18356.08	\N	0	f	\N	enviado	original	\N	2026-07-11 01:35:34.70574+00	2026-07-11 01:35:34.761288+00
ps-02	emp-001	upl-001	emp-02	01	73666629	QUISPE MAMANI JUAN CARLOS	juan@email.com	CARGO EJEMPLO	output/boleta_73666629_test.pdf	73666629	{}	{"haber_basico": 3500.0}	{}	{}	3500	520	2980	\N	0	f	\N	enviado	original	\N	2026-07-11 01:35:34.705972+00	2026-07-11 01:35:34.761294+00
ps-03	emp-001	upl-001	emp-03	01	12345678	PEREZ GOMEZ MARIA ELENA	maria@email.com	CARGO EJEMPLO	output/boleta_12345678_test.pdf	12345678	{}	{"haber_basico": 8500.0}	{}	{}	8500	1250	7250	\N	0	f	\N	enviado	original	\N	2026-07-11 01:35:34.706076+00	2026-07-11 01:35:34.761295+00
ps-04	emp-001	upl-001	emp-04	01	87654321	TORRES LOPEZ PEDRO ANTONIO	pedro@email.com	CARGO EJEMPLO	output/boleta_87654321_test.pdf	87654321	{}	{"haber_basico": 2500.0}	{}	{}	2500	380	2120	\N	0	f	\N	enviado	original	\N	2026-07-11 01:35:34.706166+00	2026-07-11 01:35:34.761297+00
ps-05	emp-001	upl-001	emp-05	01	45678912	CASTRO DIAZ ANA MARIA	ana@email.com	CARGO EJEMPLO	output/boleta_45678912_test.pdf	45678912	{}	{"haber_basico": 6000.0}	{}	{}	6000	900	5100	\N	0	f	\N	fallido	original	Connection timeout	\N	2026-07-11 01:35:34.761298+00
a96c8c07-1a12-43c9-ae42-4c611723488f	emp-001	0e1b2998-7cf9-4495-851a-9258f7591803	emp-01	01	002976650	LARSSON IDA GABRIELLA MAGDALENA	gabriella@email.com	HEAD OF OPERATIONS	output/boleta_002976650_d94caf98.pdf	002976650	{"_fila": 2, "tipo_documento": "01", "numero_documento": "002976650", "apellidos_nombres": "LARSSON IDA GABRIELLA MAGDALENA", "email": "gabriella@email.com", "cargo": "HEAD OF OPERATIONS", "fecha_ingreso": "2020-04-01", "dias_laborados": 30.0, "asignacion_familiar": "NO", "total_ingresos": 23775.29, "total_descuentos": 5419.21, "neto_pagar": 18356.08, "neto_pagar_usd": 0.0, "ing_haber_basico": 23775.29, "ing_asignacion_familiar_monto": 0.0, "ing_vacaciones": 0.0, "ing_horas_extras": 0.0, "ing_bono_productividad": 0.0, "ing_gratificacion": 0.0, "ing_cts": 0.0, "ing_feriado": 0.0, "ing_bono_trimestral": 0.0, "ing_otros": 0.0, "desc_afp_obligatorio": 5419.21, "desc_comision_afp": 0.0, "desc_prima_seguro": 0.0, "desc_onp": 0.0, "desc_renta_5ta": 0.0, "desc_otros": 0.0, "apor_essalud": 0.0, "apor_credito_eps": 0.0, "apor_vida_ley": 0.0, "apor_otros": 0.0}	{}	{}	{}	23775.29	5419.21	18356.08	\N	0	f	\N	enviado	resend_7_11	\N	2026-07-11 01:36:48.17708+00	2026-07-11 01:35:41.753409+00
24124011-a830-4be1-a05a-d0181f8e3acc	emp-001	0e1b2998-7cf9-4495-851a-9258f7591803	emp-02	01	73666629	QUISPE MAMANI JUAN CARLOS	juan@email.com	ANALISTA CONTABLE	output/boleta_73666629_fc98ce74.pdf	73666629	{"_fila": 3, "tipo_documento": "01", "numero_documento": "73666629", "apellidos_nombres": "QUISPE MAMANI JUAN CARLOS", "email": "juan@email.com", "cargo": "ANALISTA CONTABLE", "fecha_ingreso": "2021-03-15", "dias_laborados": 30.0, "asignacion_familiar": "NO", "total_ingresos": 3500.0, "total_descuentos": 520.0, "neto_pagar": 2980.0, "neto_pagar_usd": 0.0, "ing_haber_basico": 3500.0, "ing_asignacion_familiar_monto": 0.0, "ing_vacaciones": 0.0, "ing_horas_extras": 0.0, "ing_bono_productividad": 0.0, "ing_gratificacion": 0.0, "ing_cts": 0.0, "ing_feriado": 0.0, "ing_bono_trimestral": 0.0, "ing_otros": 0.0, "desc_afp_obligatorio": 520.0, "desc_comision_afp": 0.0, "desc_prima_seguro": 0.0, "desc_onp": 0.0, "desc_renta_5ta": 0.0, "desc_otros": 0.0, "apor_essalud": 0.0, "apor_credito_eps": 0.0, "apor_vida_ley": 0.0, "apor_otros": 0.0}	{}	{}	{}	3500	520	2980	\N	0	f	\N	enviado	resend_7_11	\N	2026-07-11 01:42:46.549013+00	2026-07-11 01:35:44.213033+00
0b87b16f-19f3-473c-85df-73d670649a12	emp-001	cd4aa46d-3a1f-4025-8025-3bb10397416b	emp-01	01	002976650	LARSSON IDA GABRIELLA MAGDALENA	gabriella@email.com	HEAD OF OPERATIONS	output/boleta_002976650_faa4f9c7.pdf	002976650	{"_fila": 2, "tipo_documento": "01", "numero_documento": "002976650", "apellidos_nombres": "LARSSON IDA GABRIELLA MAGDALENA", "email": "gabriella@email.com", "cargo": "HEAD OF OPERATIONS", "fecha_ingreso": "2020-04-01", "dias_laborados": 30.0, "asignacion_familiar": "NO", "total_ingresos": 23775.29, "total_descuentos": 5419.21, "neto_pagar": 18356.08, "neto_pagar_usd": 0.0, "ing_haber_basico": 23775.29, "ing_asignacion_familiar_monto": 0.0, "ing_vacaciones": 0.0, "ing_horas_extras": 0.0, "ing_bono_productividad": 0.0, "ing_gratificacion": 0.0, "ing_cts": 0.0, "ing_feriado": 0.0, "ing_bono_trimestral": 0.0, "ing_otros": 0.0, "desc_afp_obligatorio": 5419.21, "desc_comision_afp": 0.0, "desc_prima_seguro": 0.0, "desc_onp": 0.0, "desc_renta_5ta": 0.0, "desc_otros": 0.0, "apor_essalud": 0.0, "apor_credito_eps": 0.0, "apor_vida_ley": 0.0, "apor_otros": 0.0}	{}	{}	{}	23775.29	5419.21	18356.08	\N	0	f	\N	enviado	original	\N	2026-07-11 01:45:16.022642+00	2026-07-11 01:45:13.980274+00
47d7fc30-9a95-41a7-99a2-594c7e906468	emp-001	0e1b2998-7cf9-4495-851a-9258f7591803	emp-03	01	12345678	PEREZ GOMEZ MARIA ELENA	maria@email.com	GERENTE ADMINISTRATIVO	output/boleta_12345678_164a239e.pdf	12345678	{"_fila": 4, "tipo_documento": "01", "numero_documento": "12345678", "apellidos_nombres": "PEREZ GOMEZ MARIA ELENA", "email": "maria@email.com", "cargo": "GERENTE ADMINISTRATIVO", "fecha_ingreso": "2019-06-01", "dias_laborados": 30.0, "asignacion_familiar": "SI", "total_ingresos": 8602.5, "total_descuentos": 1250.0, "neto_pagar": 7352.5, "neto_pagar_usd": 0.0, "ing_haber_basico": 8500.0, "ing_asignacion_familiar_monto": 102.5, "ing_vacaciones": 0.0, "ing_horas_extras": 0.0, "ing_bono_productividad": 0.0, "ing_gratificacion": 0.0, "ing_cts": 0.0, "ing_feriado": 0.0, "ing_bono_trimestral": 0.0, "ing_otros": 0.0, "desc_afp_obligatorio": 1250.0, "desc_comision_afp": 0.0, "desc_prima_seguro": 0.0, "desc_onp": 0.0, "desc_renta_5ta": 0.0, "desc_otros": 0.0, "apor_essalud": 0.0, "apor_credito_eps": 0.0, "apor_vida_ley": 0.0, "apor_otros": 0.0}	{}	{}	{}	8602.5	1250	7352.5	\N	0	f	\N	fallido	resend_7_11	(550, b'5.7.0 Too many emails per second. Please upgrade your plan https://mailtrap.io/billing/plans/testing')	\N	2026-07-11 01:35:45.956953+00
64cf87a5-c4c2-4954-8a82-5edd80913008	emp-001	0e1b2998-7cf9-4495-851a-9258f7591803	emp-04	01	87654321	TORRES LOPEZ PEDRO ANTONIO	pedro@email.com	ASISTENTE RRHH	output/boleta_87654321_507b18ba.pdf	87654321	{"_fila": 5, "tipo_documento": "01", "numero_documento": "87654321", "apellidos_nombres": "TORRES LOPEZ PEDRO ANTONIO", "email": "pedro@email.com", "cargo": "ASISTENTE RRHH", "fecha_ingreso": "2022-01-10", "dias_laborados": 30.0, "asignacion_familiar": "NO", "total_ingresos": 2500.0, "total_descuentos": 380.0, "neto_pagar": 2120.0, "neto_pagar_usd": 0.0, "ing_haber_basico": 2500.0, "ing_asignacion_familiar_monto": 0.0, "ing_vacaciones": 0.0, "ing_horas_extras": 0.0, "ing_bono_productividad": 0.0, "ing_gratificacion": 0.0, "ing_cts": 0.0, "ing_feriado": 0.0, "ing_bono_trimestral": 0.0, "ing_otros": 0.0, "desc_afp_obligatorio": 380.0, "desc_comision_afp": 0.0, "desc_prima_seguro": 0.0, "desc_onp": 0.0, "desc_renta_5ta": 0.0, "desc_otros": 0.0, "apor_essalud": 0.0, "apor_credito_eps": 0.0, "apor_vida_ley": 0.0, "apor_otros": 0.0}	{}	{}	{}	2500	380	2120	\N	0	f	\N	fallido	resend_7_11	(550, b'5.7.0 Too many emails per second. Please upgrade your plan https://mailtrap.io/billing/plans/testing')	\N	2026-07-11 01:35:47.767551+00
b524e015-7916-405d-b5ea-4b88d6d4db42	emp-001	0e1b2998-7cf9-4495-851a-9258f7591803	emp-05	01	45678912	CASTRO DIAZ ANA MARIA	ana@email.com	CONTADOR GENERAL	output/boleta_45678912_caabaeb7.pdf	45678912	{"_fila": 6, "tipo_documento": "01", "numero_documento": "45678912", "apellidos_nombres": "CASTRO DIAZ ANA MARIA", "email": "ana@email.com", "cargo": "CONTADOR GENERAL", "fecha_ingreso": "2020-08-20", "dias_laborados": 30.0, "asignacion_familiar": "SI", "total_ingresos": 6102.5, "total_descuentos": 900.0, "neto_pagar": 5202.5, "neto_pagar_usd": 0.0, "ing_haber_basico": 6000.0, "ing_asignacion_familiar_monto": 102.5, "ing_vacaciones": 0.0, "ing_horas_extras": 0.0, "ing_bono_productividad": 0.0, "ing_gratificacion": 0.0, "ing_cts": 0.0, "ing_feriado": 0.0, "ing_bono_trimestral": 0.0, "ing_otros": 0.0, "desc_afp_obligatorio": 900.0, "desc_comision_afp": 0.0, "desc_prima_seguro": 0.0, "desc_onp": 0.0, "desc_renta_5ta": 0.0, "desc_otros": 0.0, "apor_essalud": 0.0, "apor_credito_eps": 0.0, "apor_vida_ley": 0.0, "apor_otros": 0.0}	{}	{}	{}	6102.5	900	5202.5	\N	0	f	\N	fallido	resend_7_11	(550, b'5.7.0 Too many emails per second. Please upgrade your plan https://mailtrap.io/billing/plans/testing')	\N	2026-07-11 01:35:49.644193+00
ed955801-49c3-419a-969d-8b3a3589da2d	emp-001	cd4aa46d-3a1f-4025-8025-3bb10397416b	emp-02	01	73666629	QUISPE MAMANI JUAN CARLOS	juan@email.com	ANALISTA CONTABLE	output/boleta_73666629_4f936d20.pdf	73666629	{"_fila": 3, "tipo_documento": "01", "numero_documento": "73666629", "apellidos_nombres": "QUISPE MAMANI JUAN CARLOS", "email": "juan@email.com", "cargo": "ANALISTA CONTABLE", "fecha_ingreso": "2021-03-15", "dias_laborados": 30.0, "asignacion_familiar": "NO", "total_ingresos": 3500.0, "total_descuentos": 520.0, "neto_pagar": 2980.0, "neto_pagar_usd": 0.0, "ing_haber_basico": 3500.0, "ing_asignacion_familiar_monto": 0.0, "ing_vacaciones": 0.0, "ing_horas_extras": 0.0, "ing_bono_productividad": 0.0, "ing_gratificacion": 0.0, "ing_cts": 0.0, "ing_feriado": 0.0, "ing_bono_trimestral": 0.0, "ing_otros": 0.0, "desc_afp_obligatorio": 520.0, "desc_comision_afp": 0.0, "desc_prima_seguro": 0.0, "desc_onp": 0.0, "desc_renta_5ta": 0.0, "desc_otros": 0.0, "apor_essalud": 0.0, "apor_credito_eps": 0.0, "apor_vida_ley": 0.0, "apor_otros": 0.0}	{}	{}	{}	3500	520	2980	\N	0	f	\N	no_enviado_sin_saldo	original	\N	\N	2026-07-11 01:45:16.439793+00
492e68ce-371a-4b1b-bd17-33e046002c23	emp-001	cd4aa46d-3a1f-4025-8025-3bb10397416b	emp-03	01	12345678	PEREZ GOMEZ MARIA ELENA	maria@email.com	GERENTE ADMINISTRATIVO	output/boleta_12345678_458c5e37.pdf	12345678	{"_fila": 4, "tipo_documento": "01", "numero_documento": "12345678", "apellidos_nombres": "PEREZ GOMEZ MARIA ELENA", "email": "maria@email.com", "cargo": "GERENTE ADMINISTRATIVO", "fecha_ingreso": "2019-06-01", "dias_laborados": 30.0, "asignacion_familiar": "SI", "total_ingresos": 8602.5, "total_descuentos": 1250.0, "neto_pagar": 7352.5, "neto_pagar_usd": 0.0, "ing_haber_basico": 8500.0, "ing_asignacion_familiar_monto": 102.5, "ing_vacaciones": 0.0, "ing_horas_extras": 0.0, "ing_bono_productividad": 0.0, "ing_gratificacion": 0.0, "ing_cts": 0.0, "ing_feriado": 0.0, "ing_bono_trimestral": 0.0, "ing_otros": 0.0, "desc_afp_obligatorio": 1250.0, "desc_comision_afp": 0.0, "desc_prima_seguro": 0.0, "desc_onp": 0.0, "desc_renta_5ta": 0.0, "desc_otros": 0.0, "apor_essalud": 0.0, "apor_credito_eps": 0.0, "apor_vida_ley": 0.0, "apor_otros": 0.0}	{}	{}	{}	8602.5	1250	7352.5	\N	0	f	\N	no_enviado_sin_saldo	original	\N	\N	2026-07-11 01:45:16.719112+00
ed33bd1d-9c7d-4fc1-9dc2-d8d6eb9a7fd9	emp-001	cd4aa46d-3a1f-4025-8025-3bb10397416b	emp-04	01	87654321	TORRES LOPEZ PEDRO ANTONIO	pedro@email.com	ASISTENTE RRHH	output/boleta_87654321_53c483ba.pdf	87654321	{"_fila": 5, "tipo_documento": "01", "numero_documento": "87654321", "apellidos_nombres": "TORRES LOPEZ PEDRO ANTONIO", "email": "pedro@email.com", "cargo": "ASISTENTE RRHH", "fecha_ingreso": "2022-01-10", "dias_laborados": 30.0, "asignacion_familiar": "NO", "total_ingresos": 2500.0, "total_descuentos": 380.0, "neto_pagar": 2120.0, "neto_pagar_usd": 0.0, "ing_haber_basico": 2500.0, "ing_asignacion_familiar_monto": 0.0, "ing_vacaciones": 0.0, "ing_horas_extras": 0.0, "ing_bono_productividad": 0.0, "ing_gratificacion": 0.0, "ing_cts": 0.0, "ing_feriado": 0.0, "ing_bono_trimestral": 0.0, "ing_otros": 0.0, "desc_afp_obligatorio": 380.0, "desc_comision_afp": 0.0, "desc_prima_seguro": 0.0, "desc_onp": 0.0, "desc_renta_5ta": 0.0, "desc_otros": 0.0, "apor_essalud": 0.0, "apor_credito_eps": 0.0, "apor_vida_ley": 0.0, "apor_otros": 0.0}	{}	{}	{}	2500	380	2120	\N	0	f	\N	no_enviado_sin_saldo	original	\N	\N	2026-07-11 01:45:16.994354+00
c05b2174-893f-44db-8d45-858d18fe0630	emp-001	cd4aa46d-3a1f-4025-8025-3bb10397416b	emp-05	01	45678912	CASTRO DIAZ ANA MARIA	ana@email.com	CONTADOR GENERAL	output/boleta_45678912_a0915f44.pdf	45678912	{"_fila": 6, "tipo_documento": "01", "numero_documento": "45678912", "apellidos_nombres": "CASTRO DIAZ ANA MARIA", "email": "ana@email.com", "cargo": "CONTADOR GENERAL", "fecha_ingreso": "2020-08-20", "dias_laborados": 30.0, "asignacion_familiar": "SI", "total_ingresos": 6102.5, "total_descuentos": 900.0, "neto_pagar": 5202.5, "neto_pagar_usd": 0.0, "ing_haber_basico": 6000.0, "ing_asignacion_familiar_monto": 102.5, "ing_vacaciones": 0.0, "ing_horas_extras": 0.0, "ing_bono_productividad": 0.0, "ing_gratificacion": 0.0, "ing_cts": 0.0, "ing_feriado": 0.0, "ing_bono_trimestral": 0.0, "ing_otros": 0.0, "desc_afp_obligatorio": 900.0, "desc_comision_afp": 0.0, "desc_prima_seguro": 0.0, "desc_onp": 0.0, "desc_renta_5ta": 0.0, "desc_otros": 0.0, "apor_essalud": 0.0, "apor_credito_eps": 0.0, "apor_vida_ley": 0.0, "apor_otros": 0.0}	{}	{}	{}	6102.5	900	5202.5	\N	0	f	\N	no_enviado_sin_saldo	original	\N	\N	2026-07-11 01:45:17.287615+00
\.


--
-- Data for Name: payroll_uploads; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.payroll_uploads (id, company_id, ticket_number, tipo_planilla, periodo_mes, periodo_ano, filename, file_path, total_registros, total_procesados, total_observaciones, total_enviados, total_fallidos, total_sin_saldo, estado, resumen_json, observaciones_json, detalle_envios_json, ticket_enviado_en, created_at, procesado_en) FROM stdin;
upl-001	emp-001	BLP-2025-20567890123-0001	ordinaria	9	2025	PLANILLA SETIEMBRE 2025.xls	\N	5	5	0	4	1	0	completed	{"ticket": "BLP-2025-20567890123-0001", "tipo_planilla": "ordinaria", "periodo": "09/2025", "total_registros": 5, "total_procesados": 5, "total_observaciones": 0, "total_enviados": 4, "total_fallidos": 1}	[]	[{"fila": 1, "documento": "002976650", "nombre": "LARSSON IDA GABRIELLA MAGDALENA", "email_destino": "gabriella@email.com", "estado": "enviado"}, {"fila": 2, "documento": "73666629", "nombre": "QUISPE MAMANI JUAN CARLOS", "email_destino": "juan@email.com", "estado": "enviado"}, {"fila": 3, "documento": "12345678", "nombre": "PEREZ GOMEZ MARIA ELENA", "email_destino": "maria@email.com", "estado": "enviado"}, {"fila": 4, "documento": "87654321", "nombre": "TORRES LOPEZ PEDRO ANTONIO", "email_destino": "pedro@email.com", "estado": "enviado"}, {"fila": 5, "documento": "45678912", "nombre": "CASTRO DIAZ ANA MARIA", "email_destino": "ana@email.com", "estado": "fallido", "error": "Connection timeout"}]	2026-07-11 01:35:34.705602+00	2026-07-11 01:35:34.745037+00	\N
0e1b2998-7cf9-4495-851a-9258f7591803	emp-001	BLP-2026-20567890123-0001	ordinaria	6	2026	test_planilla.xlsx	uploads/644729b1-0be3-4172-b564-251b5bac6c6e_test_planilla.xlsx	5	5	0	5	4	0	completed	{"ticket": "BLP-2026-20567890123-0001", "tipo_planilla": "ordinaria", "periodo": "06/2026", "total_registros": 5, "total_procesados": 5, "total_observaciones": 0, "total_enviados": 5, "total_fallidos": 4, "total_sin_saldo": 0}	[]	[{"fila": 2, "documento": "002976650", "nombre": "LARSSON IDA GABRIELLA MAGDALENA", "email_destino": "gabriella@email.com", "estado": "enviado", "error": null}, {"fila": 3, "documento": "73666629", "nombre": "QUISPE MAMANI JUAN CARLOS", "email_destino": "juan@email.com", "estado": "fallido", "error": "(550, b'5.7.0 Too many emails per second. Please upgrade your plan https://mailtrap.io/billing/plans/testing')"}, {"fila": 4, "documento": "12345678", "nombre": "PEREZ GOMEZ MARIA ELENA", "email_destino": "maria@email.com", "estado": "fallido", "error": "(550, b'5.7.0 Too many emails per second. Please upgrade your plan https://mailtrap.io/billing/plans/testing')"}, {"fila": 5, "documento": "87654321", "nombre": "TORRES LOPEZ PEDRO ANTONIO", "email_destino": "pedro@email.com", "estado": "fallido", "error": "(550, b'5.7.0 Too many emails per second. Please upgrade your plan https://mailtrap.io/billing/plans/testing')"}, {"fila": 6, "documento": "45678912", "nombre": "CASTRO DIAZ ANA MARIA", "email_destino": "ana@email.com", "estado": "fallido", "error": "(550, b'5.7.0 Too many emails per second. Please upgrade your plan https://mailtrap.io/billing/plans/testing')"}]	2026-07-11 01:35:51.128723+00	2026-07-11 01:35:40.72511+00	2026-07-11 01:35:40.936787+00
cd4aa46d-3a1f-4025-8025-3bb10397416b	emp-001	BLP-2026-20567890123-0002	ordinaria	7	2026	test_planilla.xlsx	uploads/ebade6b0-a1cc-431d-8ba4-74368ab0f7fb_test_planilla.xlsx	5	5	0	1	0	4	completed	{"ticket": "BLP-2026-20567890123-0002", "tipo_planilla": "ordinaria", "periodo": "07/2026", "total_registros": 5, "total_procesados": 5, "total_observaciones": 0, "total_enviados": 1, "total_fallidos": 0, "total_sin_saldo": 4}	[{"fila": 3, "documento": "73666629", "nombre": "QUISPE MAMANI JUAN CARLOS", "motivo": "Sin saldo disponible en el plan mensual", "accion": "PDF generado pero no enviado"}, {"fila": 4, "documento": "12345678", "nombre": "PEREZ GOMEZ MARIA ELENA", "motivo": "Sin saldo disponible en el plan mensual", "accion": "PDF generado pero no enviado"}, {"fila": 5, "documento": "87654321", "nombre": "TORRES LOPEZ PEDRO ANTONIO", "motivo": "Sin saldo disponible en el plan mensual", "accion": "PDF generado pero no enviado"}, {"fila": 6, "documento": "45678912", "nombre": "CASTRO DIAZ ANA MARIA", "motivo": "Sin saldo disponible en el plan mensual", "accion": "PDF generado pero no enviado"}]	[{"fila": 2, "documento": "002976650", "nombre": "LARSSON IDA GABRIELLA MAGDALENA", "email_destino": "gabriella@email.com", "estado": "enviado", "error": null}, {"fila": 3, "documento": "73666629", "nombre": "QUISPE MAMANI JUAN CARLOS", "email_destino": "juan@email.com", "estado": "no_enviado_sin_saldo", "error": null}, {"fila": 4, "documento": "12345678", "nombre": "PEREZ GOMEZ MARIA ELENA", "email_destino": "maria@email.com", "estado": "no_enviado_sin_saldo", "error": null}, {"fila": 5, "documento": "87654321", "nombre": "TORRES LOPEZ PEDRO ANTONIO", "email_destino": "pedro@email.com", "estado": "no_enviado_sin_saldo", "error": null}, {"fila": 6, "documento": "45678912", "nombre": "CASTRO DIAZ ANA MARIA", "email_destino": "ana@email.com", "estado": "no_enviado_sin_saldo", "error": null}]	2026-07-11 01:45:17.289199+00	2026-07-11 01:45:13.229837+00	2026-07-11 01:45:13.355703+00
\.


--
-- Data for Name: super_admins; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.super_admins (id, email, hashed_password, full_name, is_active, created_at) FROM stdin;
admin-001	admin@sistema.com	$2b$12$ItQ2dojoY98.Ki.b3m.lW.mF708oHRDAy3WkZYu8jRsxAvIZaML6O	Super Administrador	t	2026-07-11 01:35:34.728379+00
\.


--
-- Data for Name: unregistered_workers; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.unregistered_workers (id, payroll_upload_id, tipo_documento, numero_documento, nombre_completo, email_destino, datos_json, pdf_generado, boleta_enviada, created_at) FROM stdin;
\.


--
-- Data for Name: user_company_assignments; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.user_company_assignments (user_id, company_id, role) FROM stdin;
user-001	emp-001	admin
user-002	emp-002	admin
user-003	emp-001	admin
user-003	emp-002	admin
\.


--
-- Name: companies companies_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.companies
    ADD CONSTRAINT companies_pkey PRIMARY KEY (id);


--
-- Name: company_users company_users_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.company_users
    ADD CONSTRAINT company_users_pkey PRIMARY KEY (id);


--
-- Name: email_logs email_logs_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.email_logs
    ADD CONSTRAINT email_logs_pkey PRIMARY KEY (id);


--
-- Name: employee_company_assignments employee_company_assignments_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.employee_company_assignments
    ADD CONSTRAINT employee_company_assignments_pkey PRIMARY KEY (employee_id, company_id);


--
-- Name: employees employees_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.employees
    ADD CONSTRAINT employees_pkey PRIMARY KEY (id);


--
-- Name: license_history license_history_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.license_history
    ADD CONSTRAINT license_history_pkey PRIMARY KEY (id);


--
-- Name: monthly_send_quotas monthly_send_quotas_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.monthly_send_quotas
    ADD CONSTRAINT monthly_send_quotas_pkey PRIMARY KEY (id);


--
-- Name: pay_slips pay_slips_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.pay_slips
    ADD CONSTRAINT pay_slips_pkey PRIMARY KEY (id);


--
-- Name: payroll_uploads payroll_uploads_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.payroll_uploads
    ADD CONSTRAINT payroll_uploads_pkey PRIMARY KEY (id);


--
-- Name: super_admins super_admins_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.super_admins
    ADD CONSTRAINT super_admins_pkey PRIMARY KEY (id);


--
-- Name: unregistered_workers unregistered_workers_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.unregistered_workers
    ADD CONSTRAINT unregistered_workers_pkey PRIMARY KEY (id);


--
-- Name: user_company_assignments user_company_assignments_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.user_company_assignments
    ADD CONSTRAINT user_company_assignments_pkey PRIMARY KEY (user_id, company_id);


--
-- Name: ix_companies_ruc; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX ix_companies_ruc ON public.companies USING btree (ruc);


--
-- Name: ix_company_users_email; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX ix_company_users_email ON public.company_users USING btree (email);


--
-- Name: ix_payroll_uploads_ticket_number; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX ix_payroll_uploads_ticket_number ON public.payroll_uploads USING btree (ticket_number);


--
-- Name: ix_super_admins_email; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX ix_super_admins_email ON public.super_admins USING btree (email);


--
-- Name: email_logs email_logs_company_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.email_logs
    ADD CONSTRAINT email_logs_company_id_fkey FOREIGN KEY (company_id) REFERENCES public.companies(id);


--
-- Name: email_logs email_logs_pay_slip_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.email_logs
    ADD CONSTRAINT email_logs_pay_slip_id_fkey FOREIGN KEY (pay_slip_id) REFERENCES public.pay_slips(id);


--
-- Name: email_logs email_logs_payroll_upload_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.email_logs
    ADD CONSTRAINT email_logs_payroll_upload_id_fkey FOREIGN KEY (payroll_upload_id) REFERENCES public.payroll_uploads(id);


--
-- Name: employee_company_assignments employee_company_assignments_company_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.employee_company_assignments
    ADD CONSTRAINT employee_company_assignments_company_id_fkey FOREIGN KEY (company_id) REFERENCES public.companies(id);


--
-- Name: employee_company_assignments employee_company_assignments_employee_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.employee_company_assignments
    ADD CONSTRAINT employee_company_assignments_employee_id_fkey FOREIGN KEY (employee_id) REFERENCES public.employees(id);


--
-- Name: license_history license_history_company_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.license_history
    ADD CONSTRAINT license_history_company_id_fkey FOREIGN KEY (company_id) REFERENCES public.companies(id);


--
-- Name: monthly_send_quotas monthly_send_quotas_company_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.monthly_send_quotas
    ADD CONSTRAINT monthly_send_quotas_company_id_fkey FOREIGN KEY (company_id) REFERENCES public.companies(id);


--
-- Name: pay_slips pay_slips_company_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.pay_slips
    ADD CONSTRAINT pay_slips_company_id_fkey FOREIGN KEY (company_id) REFERENCES public.companies(id);


--
-- Name: pay_slips pay_slips_employee_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.pay_slips
    ADD CONSTRAINT pay_slips_employee_id_fkey FOREIGN KEY (employee_id) REFERENCES public.employees(id);


--
-- Name: pay_slips pay_slips_payroll_upload_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.pay_slips
    ADD CONSTRAINT pay_slips_payroll_upload_id_fkey FOREIGN KEY (payroll_upload_id) REFERENCES public.payroll_uploads(id);


--
-- Name: payroll_uploads payroll_uploads_company_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.payroll_uploads
    ADD CONSTRAINT payroll_uploads_company_id_fkey FOREIGN KEY (company_id) REFERENCES public.companies(id);


--
-- Name: unregistered_workers unregistered_workers_payroll_upload_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.unregistered_workers
    ADD CONSTRAINT unregistered_workers_payroll_upload_id_fkey FOREIGN KEY (payroll_upload_id) REFERENCES public.payroll_uploads(id);


--
-- Name: user_company_assignments user_company_assignments_company_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.user_company_assignments
    ADD CONSTRAINT user_company_assignments_company_id_fkey FOREIGN KEY (company_id) REFERENCES public.companies(id);


--
-- Name: user_company_assignments user_company_assignments_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.user_company_assignments
    ADD CONSTRAINT user_company_assignments_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.company_users(id);


--
-- PostgreSQL database dump complete
--

\unrestrict OR1kswqTcJ30Jpqu52d1Fban5eyufNVyAafh3EFuT1TrGIfvuK3xsRp1aoOhO1U

