--
-- PostgreSQL database dump
--

\restrict Di5EjoW3a2dKKJAApd3dRrxKPOe3vqeVaEs4dFsLQg7osAPoDeaBQ35ddUPMHpJ

-- Dumped from database version 15.18
-- Dumped by pg_dump version 17.10 (Debian 17.10-0+deb13u1)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: alembic_version; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.alembic_version (
    version_num character varying(32) NOT NULL
);


--
-- Name: companies; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.companies (
    id character varying(36) NOT NULL,
    name character varying(200) NOT NULL,
    ruc character varying(11) NOT NULL,
    logo_url text,
    plan_envios_mes integer NOT NULL,
    licencia_inicio date,
    licencia_fin date,
    licencia_grace_hasta date,
    licencia_estado character varying(20) NOT NULL,
    licencia_renovacion_automatica boolean NOT NULL,
    notificado_15_dias boolean NOT NULL,
    smtp_host character varying(255),
    smtp_port integer NOT NULL,
    smtp_user character varying(255),
    smtp_password text,
    smtp_from_email character varying(255),
    smtp_from_name character varying(200),
    email_subject_template text,
    email_body_template text,
    pdf_password_field character varying(50) NOT NULL,
    is_active boolean NOT NULL,
    created_at timestamp with time zone NOT NULL,
    lang character varying(5) DEFAULT 'es'::character varying,
    webhook_url text
);


--
-- Name: company_users; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.company_users (
    id character varying(36) NOT NULL,
    email character varying(255) NOT NULL,
    hashed_password character varying(255) NOT NULL,
    full_name character varying(200) NOT NULL,
    is_active boolean NOT NULL,
    created_at timestamp with time zone NOT NULL
);


--
-- Name: email_logs; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.email_logs (
    id character varying(36) NOT NULL,
    company_id character varying(36) NOT NULL,
    pay_slip_id character varying(36) NOT NULL,
    payroll_upload_id character varying(36),
    batch_key character varying(50) NOT NULL,
    destinatario_email character varying(255) NOT NULL,
    estado character varying(20) NOT NULL,
    error_message text,
    enviado_en timestamp with time zone,
    created_at timestamp with time zone NOT NULL
);


--
-- Name: employee_company_assignments; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.employee_company_assignments (
    employee_id character varying(36) NOT NULL,
    company_id character varying(36) NOT NULL,
    cargo character varying(200),
    fecha_ingreso date,
    is_active boolean NOT NULL
);


--
-- Name: employees; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.employees (
    id character varying(36) NOT NULL,
    tipo_documento character varying(2) NOT NULL,
    numero_documento character varying(20) NOT NULL,
    nombre_completo character varying(200) NOT NULL,
    email character varying(255),
    created_at timestamp with time zone NOT NULL
);


--
-- Name: license_history; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.license_history (
    id character varying(36) NOT NULL,
    company_id character varying(36) NOT NULL,
    tipo character varying(20) NOT NULL,
    inicio_anterior date,
    fin_anterior date,
    plan_anterior integer,
    inicio_nuevo date,
    fin_nuevo date,
    plan_nuevo integer,
    notas text,
    creado_por character varying(36),
    created_at timestamp with time zone NOT NULL
);


--
-- Name: monthly_send_quotas; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.monthly_send_quotas (
    id character varying(36) NOT NULL,
    company_id character varying(36) NOT NULL,
    anio integer NOT NULL,
    mes integer NOT NULL,
    limite integer NOT NULL,
    utilizados integer NOT NULL,
    created_at timestamp with time zone NOT NULL
);


--
-- Name: pay_slips; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.pay_slips (
    id character varying(36) NOT NULL,
    company_id character varying(36) NOT NULL,
    payroll_upload_id character varying(36) NOT NULL,
    employee_id character varying(36),
    tipo_documento character varying(2) NOT NULL,
    numero_documento character varying(20) NOT NULL,
    nombre_completo character varying(200) NOT NULL,
    email_destino character varying(255),
    cargo character varying(200),
    pdf_path text,
    pdf_password text,
    datos_json json,
    ingresos_json json,
    descuentos_json json,
    aportaciones_json json,
    total_ingresos double precision NOT NULL,
    total_descuentos double precision NOT NULL,
    neto_pagar double precision NOT NULL,
    neto_pagar_usd double precision,
    total_aportaciones double precision NOT NULL,
    es_observacion boolean NOT NULL,
    motivo_observacion text,
    estado_envio character varying(20) NOT NULL,
    batch_key character varying(50) NOT NULL,
    error_message text,
    enviado_en timestamp with time zone,
    created_at timestamp with time zone NOT NULL
);


--
-- Name: payroll_uploads; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.payroll_uploads (
    id character varying(36) NOT NULL,
    company_id character varying(36) NOT NULL,
    ticket_number character varying(50) NOT NULL,
    tipo_planilla character varying(30) NOT NULL,
    periodo_mes integer NOT NULL,
    periodo_ano integer NOT NULL,
    filename character varying(255) NOT NULL,
    file_path text,
    total_registros integer NOT NULL,
    total_procesados integer NOT NULL,
    total_observaciones integer NOT NULL,
    total_enviados integer NOT NULL,
    total_fallidos integer NOT NULL,
    total_sin_saldo integer NOT NULL,
    estado character varying(20) NOT NULL,
    resumen_json json,
    observaciones_json json,
    detalle_envios_json json,
    ticket_enviado_en timestamp with time zone,
    created_at timestamp with time zone NOT NULL,
    procesado_en timestamp with time zone
);


--
-- Name: super_admins; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.super_admins (
    id character varying(36) NOT NULL,
    email character varying(255) NOT NULL,
    hashed_password character varying(255) NOT NULL,
    full_name character varying(200) NOT NULL,
    is_active boolean NOT NULL,
    created_at timestamp with time zone NOT NULL
);


--
-- Name: system_settings; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.system_settings (
    key character varying(100) NOT NULL,
    value text
);


--
-- Name: unregistered_workers; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.unregistered_workers (
    id character varying(36) NOT NULL,
    payroll_upload_id character varying(36) NOT NULL,
    tipo_documento character varying(2) NOT NULL,
    numero_documento character varying(20) NOT NULL,
    nombre_completo character varying(200) NOT NULL,
    email_destino character varying(255),
    datos_json json,
    pdf_generado boolean NOT NULL,
    boleta_enviada boolean NOT NULL,
    created_at timestamp with time zone NOT NULL
);


--
-- Name: user_company_assignments; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.user_company_assignments (
    user_id character varying(36) NOT NULL,
    company_id character varying(36) NOT NULL,
    role character varying(20) NOT NULL,
    is_active boolean DEFAULT true NOT NULL
);


--
-- Name: webhook_events; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.webhook_events (
    id character varying(36) NOT NULL,
    company_id character varying(36) NOT NULL,
    pay_slip_id character varying(36),
    payroll_upload_id character varying(36),
    event_type character varying(30) NOT NULL,
    webhook_url text NOT NULL,
    payload json,
    response_status integer,
    response_body text,
    success boolean NOT NULL,
    error_message text,
    created_at timestamp with time zone NOT NULL,
    executed_at timestamp with time zone
);


--
-- Data for Name: alembic_version; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.alembic_version (version_num) FROM stdin;
002
\.


--
-- Data for Name: companies; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.companies (id, name, ruc, logo_url, plan_envios_mes, licencia_inicio, licencia_fin, licencia_grace_hasta, licencia_estado, licencia_renovacion_automatica, notificado_15_dias, smtp_host, smtp_port, smtp_user, smtp_password, smtp_from_email, smtp_from_name, email_subject_template, email_body_template, pdf_password_field, is_active, created_at, lang, webhook_url) FROM stdin;
b21ae339-c27a-4cd6-a89b-c67e36840ff6	OTERO, CARBO & ASOCIADOS S.C.	20107517058	\N	50	2026-07-11	2026-08-10	2026-10-09	activa	f	f	smtp.gmail.com	587	juan.nizama.r@gmail.com	rtiu ikzm ucra wlhq	no-reply@oteroasociados.com	Sistemas de Boletas Otero	Boleta de Pago - {{empresa}} - {{periodo}}		numero_documento	t	2026-07-11 21:04:41.459637+00	es	\N
\.


--
-- Data for Name: company_users; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.company_users (id, email, hashed_password, full_name, is_active, created_at) FROM stdin;
248c44ef-c6f9-4315-ac51-9ca46229c029	juan.nizama.r@gmail.com	$2b$12$QFawORfXoCpH5MB4F.4ZBe/DFJtOPpUn.ze90/HDnkKldzbXlfpDy	SANTIAGO OTERO	t	2026-07-11 21:04:41.684219+00
\.


--
-- Data for Name: email_logs; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.email_logs (id, company_id, pay_slip_id, payroll_upload_id, batch_key, destinatario_email, estado, error_message, enviado_en, created_at) FROM stdin;
8d6e5a42-5332-407a-b9e2-471a91b2c99a	b21ae339-c27a-4cd6-a89b-c67e36840ff6	58d7b95c-3da3-4c45-b4bc-aef3d8a76a7a	3dd96f15-3cab-4b1c-8f62-dd5a6448a7c9	original	jnizama@oteroasociados.com.pe	failed	Configuración SMTP incompleta	\N	2026-07-11 21:05:21.086676+00
336152ca-7c7e-4c9d-a80e-cbb1748b1c6f	b21ae339-c27a-4cd6-a89b-c67e36840ff6	21abec3a-cf1f-4380-9e67-1e2e5d3c28e0	3dd96f15-3cab-4b1c-8f62-dd5a6448a7c9	original	jnizama1@hotmail.com	failed	Configuración SMTP incompleta	\N	2026-07-11 21:05:21.458307+00
a3bfd8df-1406-4523-8147-d3e5c47512d5	b21ae339-c27a-4cd6-a89b-c67e36840ff6	05e903f7-b5fc-42ef-be8b-17c545bc016d	04eb9927-739d-40f3-afff-78e5d3a09596	original	jnizama@oteroasociados.com.pe	sent	\N	\N	2026-07-11 21:07:11.302186+00
5c449be5-c34a-428b-8bac-09177cb2f86d	b21ae339-c27a-4cd6-a89b-c67e36840ff6	bbcf1d2d-d2ce-464e-8cb2-31a4c73b2f51	04eb9927-739d-40f3-afff-78e5d3a09596	original	jnizama1@hotmail.com	sent	\N	\N	2026-07-11 21:07:16.382507+00
\.


--
-- Data for Name: employee_company_assignments; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.employee_company_assignments (employee_id, company_id, cargo, fecha_ingreso, is_active) FROM stdin;
\.


--
-- Data for Name: employees; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.employees (id, tipo_documento, numero_documento, nombre_completo, email, created_at) FROM stdin;
\.


--
-- Data for Name: license_history; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.license_history (id, company_id, tipo, inicio_anterior, fin_anterior, plan_anterior, inicio_nuevo, fin_nuevo, plan_nuevo, notas, creado_por, created_at) FROM stdin;
\.


--
-- Data for Name: monthly_send_quotas; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.monthly_send_quotas (id, company_id, anio, mes, limite, utilizados, created_at) FROM stdin;
e9e8bc39-3b6e-4954-9e7b-1177051ac96a	b21ae339-c27a-4cd6-a89b-c67e36840ff6	2026	7	50	4	2026-07-11 21:05:20.76265+00
\.


--
-- Data for Name: pay_slips; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.pay_slips (id, company_id, payroll_upload_id, employee_id, tipo_documento, numero_documento, nombre_completo, email_destino, cargo, pdf_path, pdf_password, datos_json, ingresos_json, descuentos_json, aportaciones_json, total_ingresos, total_descuentos, neto_pagar, neto_pagar_usd, total_aportaciones, es_observacion, motivo_observacion, estado_envio, batch_key, error_message, enviado_en, created_at) FROM stdin;
58d7b95c-3da3-4c45-b4bc-aef3d8a76a7a	b21ae339-c27a-4cd6-a89b-c67e36840ff6	3dd96f15-3cab-4b1c-8f62-dd5a6448a7c9	\N	01	40310747	NIZAMA RAMOS JUAN JOSE VICTOR	jnizama@oteroasociados.com.pe	JEFE DE SISTEMAS	output/boleta_40310747_d670f906.pdf	40310747	{"_fila": 2, "tipo_documento": "01", "numero_documento": "40310747", "apellidos_nombres": "NIZAMA RAMOS JUAN JOSE VICTOR", "email": "jnizama@oteroasociados.com.pe", "cargo": "JEFE DE SISTEMAS", "fecha_ingreso": "2024-01-15", "dias_laborados": 30.0, "asignacion_familiar": "NO", "total_ingresos": 2813.0, "total_descuentos": 270.0, "neto_pagar": 2543.0, "neto_pagar_usd": 0.0, "ing_haber_basico": 2500.0, "ing_asignacion_familiar_monto": 113.0, "ing_vacaciones": 0.0, "ing_horas_extras": 0.0, "ing_bono_productividad": 200.0, "ing_gratificacion": 0.0, "ing_cts": 0.0, "ing_feriado": 0.0, "ing_bono_trimestral": 0.0, "ing_otros": 0.0, "desc_afp_obligatorio": 250.0, "desc_comision_afp": 0.0, "desc_prima_seguro": 20.0, "desc_onp": 0.0, "desc_renta_5ta": 0.0, "desc_otros": 0.0, "apor_essalud": 225.0, "apor_credito_eps": 0.0, "apor_vida_ley": 5.0, "apor_otros": 0.0}	{}	{}	{}	2813	270	2543	\N	0	t	Empleado no registrado en el maestro	fallido	original	Configuración SMTP incompleta	\N	2026-07-11 21:05:21.075648+00
21abec3a-cf1f-4380-9e67-1e2e5d3c28e0	b21ae339-c27a-4cd6-a89b-c67e36840ff6	3dd96f15-3cab-4b1c-8f62-dd5a6448a7c9	\N	01	40908859	TAMAYO ESCOBAR JESSICA IVONNE	jnizama1@hotmail.com	JEFE DE SISTEMAS	output/boleta_40908859_1ddbb53d.pdf	40908859	{"_fila": 3, "tipo_documento": "01", "numero_documento": "40908859", "apellidos_nombres": "TAMAYO ESCOBAR JESSICA IVONNE", "email": "jnizama1@hotmail.com", "cargo": "JEFE DE SISTEMAS", "fecha_ingreso": "2024-01-15", "dias_laborados": 30.0, "asignacion_familiar": "NO", "total_ingresos": 2813.0, "total_descuentos": 270.0, "neto_pagar": 2543.0, "neto_pagar_usd": 0.0, "ing_haber_basico": 2500.0, "ing_asignacion_familiar_monto": 113.0, "ing_vacaciones": 0.0, "ing_horas_extras": 0.0, "ing_bono_productividad": 200.0, "ing_gratificacion": 0.0, "ing_cts": 0.0, "ing_feriado": 0.0, "ing_bono_trimestral": 0.0, "ing_otros": 0.0, "desc_afp_obligatorio": 250.0, "desc_comision_afp": 0.0, "desc_prima_seguro": 20.0, "desc_onp": 0.0, "desc_renta_5ta": 0.0, "desc_otros": 0.0, "apor_essalud": 225.0, "apor_credito_eps": 0.0, "apor_vida_ley": 5.0, "apor_otros": 0.0}	{}	{}	{}	2813	270	2543	\N	0	t	Empleado no registrado en el maestro	fallido	original	Configuración SMTP incompleta	\N	2026-07-11 21:05:21.448708+00
05e903f7-b5fc-42ef-be8b-17c545bc016d	b21ae339-c27a-4cd6-a89b-c67e36840ff6	04eb9927-739d-40f3-afff-78e5d3a09596	\N	01	40310747	NIZAMA RAMOS JUAN JOSE VICTOR	jnizama@oteroasociados.com.pe	JEFE DE SISTEMAS	output/boleta_40310747_20005181.pdf	40310747	{"_fila": 2, "tipo_documento": "01", "numero_documento": "40310747", "apellidos_nombres": "NIZAMA RAMOS JUAN JOSE VICTOR", "email": "jnizama@oteroasociados.com.pe", "cargo": "JEFE DE SISTEMAS", "fecha_ingreso": "2024-01-15", "dias_laborados": 30.0, "asignacion_familiar": "NO", "total_ingresos": 2813.0, "total_descuentos": 270.0, "neto_pagar": 2543.0, "neto_pagar_usd": 0.0, "ing_haber_basico": 2500.0, "ing_asignacion_familiar_monto": 113.0, "ing_vacaciones": 0.0, "ing_horas_extras": 0.0, "ing_bono_productividad": 200.0, "ing_gratificacion": 0.0, "ing_cts": 0.0, "ing_feriado": 0.0, "ing_bono_trimestral": 0.0, "ing_otros": 0.0, "desc_afp_obligatorio": 250.0, "desc_comision_afp": 0.0, "desc_prima_seguro": 20.0, "desc_onp": 0.0, "desc_renta_5ta": 0.0, "desc_otros": 0.0, "apor_essalud": 225.0, "apor_credito_eps": 0.0, "apor_vida_ley": 5.0, "apor_otros": 0.0}	{}	{}	{}	2813	270	2543	\N	0	t	Empleado no registrado en el maestro	enviado	original	\N	2026-07-11 21:07:11.297398+00	2026-07-11 21:07:05.435019+00
bbcf1d2d-d2ce-464e-8cb2-31a4c73b2f51	b21ae339-c27a-4cd6-a89b-c67e36840ff6	04eb9927-739d-40f3-afff-78e5d3a09596	\N	01	40908859	TAMAYO ESCOBAR JESSICA IVONNE	jnizama1@hotmail.com	JEFE DE SISTEMAS	output/boleta_40908859_4cb42828.pdf	40908859	{"_fila": 3, "tipo_documento": "01", "numero_documento": "40908859", "apellidos_nombres": "TAMAYO ESCOBAR JESSICA IVONNE", "email": "jnizama1@hotmail.com", "cargo": "JEFE DE SISTEMAS", "fecha_ingreso": "2024-01-15", "dias_laborados": 30.0, "asignacion_familiar": "NO", "total_ingresos": 2813.0, "total_descuentos": 270.0, "neto_pagar": 2543.0, "neto_pagar_usd": 0.0, "ing_haber_basico": 2500.0, "ing_asignacion_familiar_monto": 113.0, "ing_vacaciones": 0.0, "ing_horas_extras": 0.0, "ing_bono_productividad": 200.0, "ing_gratificacion": 0.0, "ing_cts": 0.0, "ing_feriado": 0.0, "ing_bono_trimestral": 0.0, "ing_otros": 0.0, "desc_afp_obligatorio": 250.0, "desc_comision_afp": 0.0, "desc_prima_seguro": 20.0, "desc_onp": 0.0, "desc_renta_5ta": 0.0, "desc_otros": 0.0, "apor_essalud": 225.0, "apor_credito_eps": 0.0, "apor_vida_ley": 5.0, "apor_otros": 0.0}	{}	{}	{}	2813	270	2543	\N	0	t	Empleado no registrado en el maestro	enviado	original	\N	2026-07-11 21:07:16.37722+00	2026-07-11 21:07:11.564434+00
\.


--
-- Data for Name: payroll_uploads; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.payroll_uploads (id, company_id, ticket_number, tipo_planilla, periodo_mes, periodo_ano, filename, file_path, total_registros, total_procesados, total_observaciones, total_enviados, total_fallidos, total_sin_saldo, estado, resumen_json, observaciones_json, detalle_envios_json, ticket_enviado_en, created_at, procesado_en) FROM stdin;
3dd96f15-3cab-4b1c-8f62-dd5a6448a7c9	b21ae339-c27a-4cd6-a89b-c67e36840ff6	BLP-2026-20107517058-0001	ordinaria	7	2026	plantilla_boletas.xlsx	uploads/9f0091d2-4482-41d5-ac2f-4f52ce884f14_plantilla_boletas.xlsx	2	2	2	2	2	0	completed	{"ticket": "BLP-2026-20107517058-0001", "tipo_planilla": "ordinaria", "periodo": "07/2026", "total_registros": 2, "total_procesados": 2, "total_observaciones": 2, "total_enviados": 2, "total_fallidos": 2, "total_sin_saldo": 0}	[{"fila": 2, "documento": "40310747", "nombre": "NIZAMA RAMOS JUAN JOSE VICTOR", "motivo": "Empleado no registrado en el maestro", "accion": "Boleta enviada al correo del archivo Excel"}, {"fila": 3, "documento": "40908859", "nombre": "TAMAYO ESCOBAR JESSICA IVONNE", "motivo": "Empleado no registrado en el maestro", "accion": "Boleta enviada al correo del archivo Excel"}]	[{"fila": 2, "documento": "40310747", "nombre": "NIZAMA RAMOS JUAN JOSE VICTOR", "email_destino": "jnizama@oteroasociados.com.pe (por observaci\\u00f3n)", "estado": "fallido", "error": "Configuraci\\u00f3n SMTP incompleta"}, {"fila": 3, "documento": "40908859", "nombre": "TAMAYO ESCOBAR JESSICA IVONNE", "email_destino": "jnizama1@hotmail.com (por observaci\\u00f3n)", "estado": "fallido", "error": "Configuraci\\u00f3n SMTP incompleta"}]	2026-07-11 21:05:21.451457+00	2026-07-11 21:05:12.39744+00	2026-07-11 21:05:20.359316+00
04eb9927-739d-40f3-afff-78e5d3a09596	b21ae339-c27a-4cd6-a89b-c67e36840ff6	BLP-2026-20107517058-0002	gratificacion	7	2026	plantilla_boletas.xlsx	uploads/e061b4a3-08c0-43ee-8130-7ec751f6c8e3_plantilla_boletas.xlsx	2	2	2	2	0	0	completed	{"ticket": "BLP-2026-20107517058-0002", "tipo_planilla": "gratificacion", "periodo": "07/2026", "total_registros": 2, "total_procesados": 2, "total_observaciones": 2, "total_enviados": 2, "total_fallidos": 0, "total_sin_saldo": 0}	[{"fila": 2, "documento": "40310747", "nombre": "NIZAMA RAMOS JUAN JOSE VICTOR", "motivo": "Empleado no registrado en el maestro", "accion": "Boleta enviada al correo del archivo Excel"}, {"fila": 3, "documento": "40908859", "nombre": "TAMAYO ESCOBAR JESSICA IVONNE", "motivo": "Empleado no registrado en el maestro", "accion": "Boleta enviada al correo del archivo Excel"}]	[{"fila": 2, "documento": "40310747", "nombre": "NIZAMA RAMOS JUAN JOSE VICTOR", "email_destino": "jnizama@oteroasociados.com.pe (por observaci\\u00f3n)", "estado": "enviado", "error": null}, {"fila": 3, "documento": "40908859", "nombre": "TAMAYO ESCOBAR JESSICA IVONNE", "email_destino": "jnizama1@hotmail.com (por observaci\\u00f3n)", "estado": "enviado", "error": null}]	2026-07-11 21:07:16.37745+00	2026-07-11 21:07:00.662388+00	2026-07-11 21:07:05.084261+00
\.


--
-- Data for Name: super_admins; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.super_admins (id, email, hashed_password, full_name, is_active, created_at) FROM stdin;
admin-001	admin@sistema.com	$2b$12$VajFCDMUti3lwESMbOQZfOzjaKX8L9uEzR.5e4WSuaZtH5F8pSinu	Super Administrador	t	2026-07-11 15:13:08.551896+00
\.


--
-- Data for Name: system_settings; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.system_settings (key, value) FROM stdin;
smtp_host	smtp.gmail.com
smtp_port	587
smtp_user	jn835513@gmail.com
smtp_password	aioz zesb vcik tvlg
smtp_from_email	noreply@boletasaas.com
smtp_from_name	Boleta SaaS
notification_email	jn835513@gmail.com
\.


--
-- Data for Name: unregistered_workers; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.unregistered_workers (id, payroll_upload_id, tipo_documento, numero_documento, nombre_completo, email_destino, datos_json, pdf_generado, boleta_enviada, created_at) FROM stdin;
8f760c54-3bc2-4aa7-9975-061d2bb794c7	3dd96f15-3cab-4b1c-8f62-dd5a6448a7c9	01	40310747	NIZAMA RAMOS JUAN JOSE VICTOR	jnizama@oteroasociados.com.pe	{"_fila": 2, "tipo_documento": "01", "numero_documento": "40310747", "apellidos_nombres": "NIZAMA RAMOS JUAN JOSE VICTOR", "email": "jnizama@oteroasociados.com.pe", "cargo": "JEFE DE SISTEMAS", "fecha_ingreso": "2024-01-15", "dias_laborados": 30.0, "asignacion_familiar": "NO", "total_ingresos": 2813.0, "total_descuentos": 270.0, "neto_pagar": 2543.0, "neto_pagar_usd": 0.0, "ing_haber_basico": 2500.0, "ing_asignacion_familiar_monto": 113.0, "ing_vacaciones": 0.0, "ing_horas_extras": 0.0, "ing_bono_productividad": 200.0, "ing_gratificacion": 0.0, "ing_cts": 0.0, "ing_feriado": 0.0, "ing_bono_trimestral": 0.0, "ing_otros": 0.0, "desc_afp_obligatorio": 250.0, "desc_comision_afp": 0.0, "desc_prima_seguro": 20.0, "desc_onp": 0.0, "desc_renta_5ta": 0.0, "desc_otros": 0.0, "apor_essalud": 225.0, "apor_credito_eps": 0.0, "apor_vida_ley": 5.0, "apor_otros": 0.0}	t	f	2026-07-11 21:05:21.07946+00
c3e7661d-099e-4a17-b2e6-d84cf705baf6	3dd96f15-3cab-4b1c-8f62-dd5a6448a7c9	01	40908859	TAMAYO ESCOBAR JESSICA IVONNE	jnizama1@hotmail.com	{"_fila": 3, "tipo_documento": "01", "numero_documento": "40908859", "apellidos_nombres": "TAMAYO ESCOBAR JESSICA IVONNE", "email": "jnizama1@hotmail.com", "cargo": "JEFE DE SISTEMAS", "fecha_ingreso": "2024-01-15", "dias_laborados": 30.0, "asignacion_familiar": "NO", "total_ingresos": 2813.0, "total_descuentos": 270.0, "neto_pagar": 2543.0, "neto_pagar_usd": 0.0, "ing_haber_basico": 2500.0, "ing_asignacion_familiar_monto": 113.0, "ing_vacaciones": 0.0, "ing_horas_extras": 0.0, "ing_bono_productividad": 200.0, "ing_gratificacion": 0.0, "ing_cts": 0.0, "ing_feriado": 0.0, "ing_bono_trimestral": 0.0, "ing_otros": 0.0, "desc_afp_obligatorio": 250.0, "desc_comision_afp": 0.0, "desc_prima_seguro": 20.0, "desc_onp": 0.0, "desc_renta_5ta": 0.0, "desc_otros": 0.0, "apor_essalud": 225.0, "apor_credito_eps": 0.0, "apor_vida_ley": 5.0, "apor_otros": 0.0}	t	f	2026-07-11 21:05:21.450055+00
7b2c79eb-d871-4f88-85ce-24caa9f6a519	04eb9927-739d-40f3-afff-78e5d3a09596	01	40310747	NIZAMA RAMOS JUAN JOSE VICTOR	jnizama@oteroasociados.com.pe	{"_fila": 2, "tipo_documento": "01", "numero_documento": "40310747", "apellidos_nombres": "NIZAMA RAMOS JUAN JOSE VICTOR", "email": "jnizama@oteroasociados.com.pe", "cargo": "JEFE DE SISTEMAS", "fecha_ingreso": "2024-01-15", "dias_laborados": 30.0, "asignacion_familiar": "NO", "total_ingresos": 2813.0, "total_descuentos": 270.0, "neto_pagar": 2543.0, "neto_pagar_usd": 0.0, "ing_haber_basico": 2500.0, "ing_asignacion_familiar_monto": 113.0, "ing_vacaciones": 0.0, "ing_horas_extras": 0.0, "ing_bono_productividad": 200.0, "ing_gratificacion": 0.0, "ing_cts": 0.0, "ing_feriado": 0.0, "ing_bono_trimestral": 0.0, "ing_otros": 0.0, "desc_afp_obligatorio": 250.0, "desc_comision_afp": 0.0, "desc_prima_seguro": 20.0, "desc_onp": 0.0, "desc_renta_5ta": 0.0, "desc_otros": 0.0, "apor_essalud": 225.0, "apor_credito_eps": 0.0, "apor_vida_ley": 5.0, "apor_otros": 0.0}	t	f	2026-07-11 21:07:05.436787+00
b3bfce79-c9c5-473b-8533-74ef009134b8	04eb9927-739d-40f3-afff-78e5d3a09596	01	40908859	TAMAYO ESCOBAR JESSICA IVONNE	jnizama1@hotmail.com	{"_fila": 3, "tipo_documento": "01", "numero_documento": "40908859", "apellidos_nombres": "TAMAYO ESCOBAR JESSICA IVONNE", "email": "jnizama1@hotmail.com", "cargo": "JEFE DE SISTEMAS", "fecha_ingreso": "2024-01-15", "dias_laborados": 30.0, "asignacion_familiar": "NO", "total_ingresos": 2813.0, "total_descuentos": 270.0, "neto_pagar": 2543.0, "neto_pagar_usd": 0.0, "ing_haber_basico": 2500.0, "ing_asignacion_familiar_monto": 113.0, "ing_vacaciones": 0.0, "ing_horas_extras": 0.0, "ing_bono_productividad": 200.0, "ing_gratificacion": 0.0, "ing_cts": 0.0, "ing_feriado": 0.0, "ing_bono_trimestral": 0.0, "ing_otros": 0.0, "desc_afp_obligatorio": 250.0, "desc_comision_afp": 0.0, "desc_prima_seguro": 20.0, "desc_onp": 0.0, "desc_renta_5ta": 0.0, "desc_otros": 0.0, "apor_essalud": 225.0, "apor_credito_eps": 0.0, "apor_vida_ley": 5.0, "apor_otros": 0.0}	t	f	2026-07-11 21:07:11.565808+00
\.


--
-- Data for Name: user_company_assignments; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.user_company_assignments (user_id, company_id, role, is_active) FROM stdin;
248c44ef-c6f9-4315-ac51-9ca46229c029	b21ae339-c27a-4cd6-a89b-c67e36840ff6	admin	t
\.


--
-- Data for Name: webhook_events; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.webhook_events (id, company_id, pay_slip_id, payroll_upload_id, event_type, webhook_url, payload, response_status, response_body, success, error_message, created_at, executed_at) FROM stdin;
\.


--
-- Name: alembic_version alembic_version_pkc; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.alembic_version
    ADD CONSTRAINT alembic_version_pkc PRIMARY KEY (version_num);


--
-- Name: companies companies_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.companies
    ADD CONSTRAINT companies_pkey PRIMARY KEY (id);


--
-- Name: company_users company_users_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.company_users
    ADD CONSTRAINT company_users_pkey PRIMARY KEY (id);


--
-- Name: email_logs email_logs_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.email_logs
    ADD CONSTRAINT email_logs_pkey PRIMARY KEY (id);


--
-- Name: employee_company_assignments employee_company_assignments_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.employee_company_assignments
    ADD CONSTRAINT employee_company_assignments_pkey PRIMARY KEY (employee_id, company_id);


--
-- Name: employees employees_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.employees
    ADD CONSTRAINT employees_pkey PRIMARY KEY (id);


--
-- Name: license_history license_history_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.license_history
    ADD CONSTRAINT license_history_pkey PRIMARY KEY (id);


--
-- Name: monthly_send_quotas monthly_send_quotas_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.monthly_send_quotas
    ADD CONSTRAINT monthly_send_quotas_pkey PRIMARY KEY (id);


--
-- Name: pay_slips pay_slips_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.pay_slips
    ADD CONSTRAINT pay_slips_pkey PRIMARY KEY (id);


--
-- Name: payroll_uploads payroll_uploads_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.payroll_uploads
    ADD CONSTRAINT payroll_uploads_pkey PRIMARY KEY (id);


--
-- Name: super_admins super_admins_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.super_admins
    ADD CONSTRAINT super_admins_pkey PRIMARY KEY (id);


--
-- Name: system_settings system_settings_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.system_settings
    ADD CONSTRAINT system_settings_pkey PRIMARY KEY (key);


--
-- Name: unregistered_workers unregistered_workers_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.unregistered_workers
    ADD CONSTRAINT unregistered_workers_pkey PRIMARY KEY (id);


--
-- Name: user_company_assignments user_company_assignments_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.user_company_assignments
    ADD CONSTRAINT user_company_assignments_pkey PRIMARY KEY (user_id, company_id);


--
-- Name: webhook_events webhook_events_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.webhook_events
    ADD CONSTRAINT webhook_events_pkey PRIMARY KEY (id);


--
-- Name: ix_companies_ruc; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX ix_companies_ruc ON public.companies USING btree (ruc);


--
-- Name: ix_company_users_email; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX ix_company_users_email ON public.company_users USING btree (email);


--
-- Name: ix_payroll_uploads_ticket_number; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX ix_payroll_uploads_ticket_number ON public.payroll_uploads USING btree (ticket_number);


--
-- Name: ix_super_admins_email; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX ix_super_admins_email ON public.super_admins USING btree (email);


--
-- Name: email_logs email_logs_company_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.email_logs
    ADD CONSTRAINT email_logs_company_id_fkey FOREIGN KEY (company_id) REFERENCES public.companies(id);


--
-- Name: email_logs email_logs_pay_slip_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.email_logs
    ADD CONSTRAINT email_logs_pay_slip_id_fkey FOREIGN KEY (pay_slip_id) REFERENCES public.pay_slips(id);


--
-- Name: email_logs email_logs_payroll_upload_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.email_logs
    ADD CONSTRAINT email_logs_payroll_upload_id_fkey FOREIGN KEY (payroll_upload_id) REFERENCES public.payroll_uploads(id);


--
-- Name: employee_company_assignments employee_company_assignments_company_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.employee_company_assignments
    ADD CONSTRAINT employee_company_assignments_company_id_fkey FOREIGN KEY (company_id) REFERENCES public.companies(id);


--
-- Name: employee_company_assignments employee_company_assignments_employee_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.employee_company_assignments
    ADD CONSTRAINT employee_company_assignments_employee_id_fkey FOREIGN KEY (employee_id) REFERENCES public.employees(id);


--
-- Name: license_history license_history_company_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.license_history
    ADD CONSTRAINT license_history_company_id_fkey FOREIGN KEY (company_id) REFERENCES public.companies(id);


--
-- Name: monthly_send_quotas monthly_send_quotas_company_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.monthly_send_quotas
    ADD CONSTRAINT monthly_send_quotas_company_id_fkey FOREIGN KEY (company_id) REFERENCES public.companies(id);


--
-- Name: pay_slips pay_slips_company_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.pay_slips
    ADD CONSTRAINT pay_slips_company_id_fkey FOREIGN KEY (company_id) REFERENCES public.companies(id);


--
-- Name: pay_slips pay_slips_employee_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.pay_slips
    ADD CONSTRAINT pay_slips_employee_id_fkey FOREIGN KEY (employee_id) REFERENCES public.employees(id);


--
-- Name: pay_slips pay_slips_payroll_upload_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.pay_slips
    ADD CONSTRAINT pay_slips_payroll_upload_id_fkey FOREIGN KEY (payroll_upload_id) REFERENCES public.payroll_uploads(id);


--
-- Name: payroll_uploads payroll_uploads_company_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.payroll_uploads
    ADD CONSTRAINT payroll_uploads_company_id_fkey FOREIGN KEY (company_id) REFERENCES public.companies(id);


--
-- Name: unregistered_workers unregistered_workers_payroll_upload_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.unregistered_workers
    ADD CONSTRAINT unregistered_workers_payroll_upload_id_fkey FOREIGN KEY (payroll_upload_id) REFERENCES public.payroll_uploads(id);


--
-- Name: user_company_assignments user_company_assignments_company_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.user_company_assignments
    ADD CONSTRAINT user_company_assignments_company_id_fkey FOREIGN KEY (company_id) REFERENCES public.companies(id);


--
-- Name: user_company_assignments user_company_assignments_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.user_company_assignments
    ADD CONSTRAINT user_company_assignments_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.company_users(id);


--
-- Name: webhook_events webhook_events_company_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.webhook_events
    ADD CONSTRAINT webhook_events_company_id_fkey FOREIGN KEY (company_id) REFERENCES public.companies(id);


--
-- Name: webhook_events webhook_events_pay_slip_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.webhook_events
    ADD CONSTRAINT webhook_events_pay_slip_id_fkey FOREIGN KEY (pay_slip_id) REFERENCES public.pay_slips(id);


--
-- Name: webhook_events webhook_events_payroll_upload_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.webhook_events
    ADD CONSTRAINT webhook_events_payroll_upload_id_fkey FOREIGN KEY (payroll_upload_id) REFERENCES public.payroll_uploads(id);


--
-- PostgreSQL database dump complete
--

\unrestrict Di5EjoW3a2dKKJAApd3dRrxKPOe3vqeVaEs4dFsLQg7osAPoDeaBQ35ddUPMHpJ

